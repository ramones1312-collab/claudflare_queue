# FILES TO REPLACE · Multi-Hub Dispatcher V0.1 → V0.1.1

Extract this ZIP **inside** the existing project folder (the one with `docker-compose.yml`): paths are relative to it.

| PATH | ACTION | SHA256 NEW | PURPOSE |
|---|---|---|---|
| `README_NAS_INSTALL.md` | REPLACE | `6538c55dcb4266371d2605c07ae0d841428a48d9676329c7457c81c2f540a7a6` | version / documentation |
| `TEST_REPORT.md` | REPLACE | `ce350eff723ea858e27de95eab22e18bfbd1bf3287f56548a356444045aba9c4` | version / documentation |
| `VERSION` | REPLACE | `97b82de8c87c6ea985d3b0e18eee4018f1acc2834f7f5f1388493dba26fb9dc3` | version / documentation |
| `docker-compose.yml` | REPLACE | `dd4e7ae202b2ba9ec1bfb8ab05f61820d6074e4ca9a4616d1a73ae09d247649e` | image tag 0.1.1 only (ports, volumes, security unchanged) |
| `package-lock.json` | REPLACE | `4285ed2d82a03107fabd2b8722663c8d93f6d65a5c53f2af6105b3cdfc552fea` | version / documentation |
| `package.json` | REPLACE | `970d28410b779f62d100a62d81dc54353554df8f5daeb82f146c1c68dea48300` | version / documentation |
| `secrets/audit_admin_token` | ADD | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` | EMPTY placeholder: put the audit web password here (not a real secret) |
| `src/audit-ui/app.js` | ADD | `388e4e0413818fd8099e772575b7c57cd99217e8e1971798f16c01c689319151` | NEW /audit web page (no framework), served behind Basic Auth |
| `src/audit-ui/index.html` | ADD | `ab1ff41747fbe1b7286417c3ca3fbfdc4e1bf5a2eb5467258673b4fc607443ed` | NEW /audit web page (no framework), served behind Basic Auth |
| `src/audit.mjs` | ADD | `971cb60b72f597baa6948451a9418091235e4acd057eb2ffd3b0056090c92201` | NEW audit module: audit_events table, status file, retention, /audit UI/API/exports |
| `src/config.mjs` | REPLACE | `23266838228458df59266d77dbbc93c90dfdc5948a74758e9f0a2839c492491c` | passes the optional "audit" block through (core validation unchanged) |
| `src/dispatcher.mjs` | REPLACE | `ba641bbdef4f8d9c2c30ebf06bc70d89b70315ecff0620f303825e1ceb470d53` | audit rows per delivery attempt/result (delivery logic unchanged) |
| `src/main.mjs` | REPLACE | `59e2bd108efef9af7136d58a503dc12a369807ec6fd344ed3d1e11b10fa54649` | creates the audit; DISPATCHER_STARTED/STOPPING; CONFIG_INVALID recorded best-effort |
| `src/server.mjs` | REPLACE | `5afbf1ad45529302f5507b61990acb8b73b5827ae601ebf3466c550a1bbb9de6` | request_id, ingress audit rows after the ACK, /audit routing, optional audit fields in /health |
| `test/audit-export.test.mjs` | ADD | `b1f6ba5094aaeeba543292e60d3f271539e3273d6f36c3e76c92044397ddaa8a` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/audit-helpers.mjs` | ADD | `22c856427a32ceaea068a69cf9263b5c9ace0ec150770f9d332a99ba2a551301` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/audit-security.test.mjs` | ADD | `784b5a338830c845e7c379d262d6156a76145414d9d93debea87ca5501150be5` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/audit.test.mjs` | ADD | `d8a888f73bbe0e9006e6af3557549e85c4b12775454175d30482f4ef43ee1bc4` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/config.test.mjs` | ADD | `979c94a59f63901ad8885ac620c13e68363a409ba8305c22858061aea233f682` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/delivery.test.mjs` | ADD | `2c11c9947c100b5e5a704486f8b0c80d02dcb3c639964cd25f0550c3392fb413` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/durability.test.mjs` | ADD | `c0159ab7f30d0da863cbb22d4069e5edd50f2e08e9e2ab56ee4e37f13784aaa7` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/helpers.mjs` | ADD | `24606165a339397fccdbbc31e6f43e8313a184564881e069b4ad314aa305ec84` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/ingress.test.mjs` | ADD | `d12a5d6015117a7a49f090b158eebec8304af6fff71148f07ab4822977f765e2` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `test/regression.test.mjs` | ADD | `96cbe0a30e040897983b8918e48ab1756c1052acbc5ff077cf24007a77787dae` | tests (not used at runtime; excluded from the image by .dockerignore) |
| `MANIFEST.sha256` | REPLACE | `27830c49207b229ec845a8ea7304f8246cd8e612ffc1f1a412900111a6fe1744` | integrity list of V0.1.1 (config/ and secrets/ are expected to differ on your NAS) |
| `FILES_TO_REPLACE.md` | ADD | (this file) | this table |

## DO NOT REPLACE

```
config/destinations.json
data/
secrets/ingress_webhook_token
secrets/hub_a_webhook_token
secrets/hub_b_webhook_token
```

The only new secret is `secrets/audit_admin_token`, shipped **empty**: write the audit web password into it (16+ characters, different from every other secret).

No V0.1 file is removed.
